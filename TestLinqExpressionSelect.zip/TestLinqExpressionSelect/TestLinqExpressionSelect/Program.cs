﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace TestLinqExpressionSelect
{
  class Program
  {

    public class MyData
    {
      public string postcode { get; set; }
      public decimal? value1 { get; set; }
      public int? value2 { get; set; }
    }

    public class Result
    {
      public string postcode { get; set; }
      public decimal? decimalValue { get; set; }
    }

    //private static readonly Type AnonymousType = new { postcode = "", decimalValue = 0.0M }.GetType();

    static void Main(string[] args)
    {
      var data = new List<MyData>()
      {
        new MyData { postcode ="1000", value1 = 12.3M, value2 = 23 },
        new MyData { postcode ="2210", value1 = 14.6M, value2 = 5 },
        new MyData { postcode ="3105", value1 = 17.76M, value2 = 18 },
        new MyData { postcode ="4321", value1 = 32.12M, value2 = 16 },
        new MyData { postcode ="6543", value1 = 16.81M, value2 = 6 },
        new MyData { postcode ="7261", value1 = 45.67M, value2 = 12 }
      };

      var q1 = data.Where(r => r.postcode.Contains("2"));
      var q4 = q1.Select(Helpers.DynamicSelectFieldsGenerator<MyData, Result>(new[] { "postcode", "value1" }, new[] { "postcode", "decimalValue" }));
      var result2 = q4.ToList();
      result2.ForEach(r => { Console.WriteLine( "postcode:{0} decimalValue:{1}", r.postcode, r.decimalValue); });
      Console.ReadLine();
    }


  }

  public static class Helpers
  {
    public static Func<InputType, OutputType> DynamicSelectGenerator<InputType,OutputType>(string Fields = "")
    {
      string[] EntityFields;
      if (Fields == "")
        // get Properties of the T
        EntityFields = typeof(InputType).GetProperties().Select(propertyInfo => propertyInfo.Name).ToArray();
      else
        EntityFields = Fields.Split(',');

      // input parameter "o"
      var xParameter = Expression.Parameter(typeof(InputType), "o");

      // new statement "new Data()"
      var xNew = Expression.New(typeof(InputType));

      var memberFields = typeof(InputType).GetFields();
      var memberProperties = typeof(InputType).GetProperties();

      // create initializers
      var bindings = EntityFields.Select(o => o.Trim())
          .Select(o =>
          {

            // property "Field1"
            //var mi = typeof(InputType).GetProperty(o);
            var mi = typeof(InputType).GetProperty(o);

            // original value "o.Field1"
            var xOriginal = Expression.Property(xParameter, mi);

              // set value "Field1 = o.Field1"
              return Expression.Bind(mi, xOriginal);
          }
      );

      // initialization "new Data { Field1 = o.Field1, Field2 = o.Field2 }"
      var xInit = Expression.MemberInit(xNew, bindings);

      // expression "o => new Data { Field1 = o.Field1, Field2 = o.Field2 }"
      var lambda = Expression.Lambda<Func<InputType, OutputType>>(xInit, xParameter);

      // compile to Func<Data, Data>
      return lambda.Compile();
    }

    public static Func<InputType, OutputType> DynamicSelectFieldsGenerator<InputType, OutputType>(string[] sourceFields, string[] destinationFields)
    {
      if (sourceFields.Length != destinationFields.Length)
      {
        throw new Exception("Must have a direct one to one translation between source and destination fields.");
      }

      // input parameter "x"
      var xParameter = Expression.Parameter(typeof(InputType), "x");

      var memberAssignmentList = new List<MemberAssignment>();
      for (var i = 0; i < sourceFields.Length; i++)
      {
        var sourceProperty = typeof(InputType).GetProperty(sourceFields[i]);
        var sourceParameter = Expression.Property(xParameter, sourceProperty);
        var destinationProperty = typeof(OutputType).GetProperty(destinationFields[i]);
        var newExpression = Expression.Bind(destinationProperty, sourceParameter);
        memberAssignmentList.Add(newExpression);
      }

      // new statement "new OutputField()"
      var xNew = Expression.New(typeof(OutputType));
      // initialization "new OutputType { Field = x.Field1, OtherField = x.Field2 }"
      var xInit = Expression.MemberInit(xNew, memberAssignmentList.ToArray());

      // expression "x => new Data { Field1 = x.Field1, Field2 = x.Field2 }"
      var lambda = Expression.Lambda<Func<InputType, OutputType>>(xInit, xParameter);

      // compile to Func<Data, Data>
      return lambda.Compile();
    }

  }
}
